#include "lcd.h"
#include "stdlib.h"
#include "cfont.h"

#include "task.h" 
   

 				 
//LCD�Ļ�����ɫ�ͱ���ɫ	   
uint16_t POINT_COLOR=0x0000;	//������ɫ
uint16_t BACK_COLOR=0xFFFF;  //����ɫ 

//����LCD��Ҫ����
_lcd_dev lcddev;


void Delay_ms(uint32_t ms)
{

    vTaskDelay(ms);

//   for (uint32_t i = 0; i < 100000; i++)
//   {
//     for (uint32_t j = 0; j < ms; j++)
//     {

//     }
//   }
}



gpio_t  gpio_rst;
gpio_t  gpio_rs;
gpio_t  gpio_cs;

gpio_t  gpio_miso;

void spi_io_init(void)
{
	gpio_init(&gpio_rst, SPI_RST_PIN);
	gpio_dir(&gpio_rst, PIN_OUTPUT);        // Direction: Output
	gpio_mode(&gpio_rst, PullNone);         // No pull
	gpio_write(&gpio_rst,1);                //default high

	gpio_init(&gpio_rs, SPI_RS_PIN);
	gpio_dir(&gpio_rs, PIN_OUTPUT);        // Direction: Output
	gpio_mode(&gpio_rs, PullNone);         // No pull	

	gpio_init(&gpio_cs, SPI_CS_PIN);
	gpio_dir(&gpio_cs, PIN_OUTPUT);        // Direction: Output
	gpio_mode(&gpio_cs, PullNone);         // No pull	
    gpio_write(&gpio_cs,0);     

	// gpio_init(&gpio_miso, SPI_MISO_PIN);
	// gpio_dir(&gpio_miso, PIN_OUTPUT);        // Direction: Output
	// gpio_mode(&gpio_miso, PullNone);         // No pull	
    // gpio_write(&gpio_miso,1);        
}
	
		   
//д�Ĵ�������
//regval:�Ĵ���ֵ
//void LCD_WR_REG(uint16_t regval)
//{ 
//	SPILCD_CS_RESET;  //LCD_CS=0
//	SPILCD_RS_RESET;
//	SPI1_ReadWriteByte(regval&0x00FF);
//	SPILCD_CS_SET;  //LCD_CS=1	   		 
//}
////дLCD����
////data:Ҫд����?
//void LCD_WR_DATA(uint16_t data)
//{
// 	SPILCD_CS_RESET;  //LCD_CS=0
//	SPILCD_RS_SET;	
//	SPI1_ReadWriteByte(data>>8);
//	SPI1_ReadWriteByte(data);
//	SPILCD_CS_SET;  //LCD_CS=1		
//}
//void LCD_WR_DATA8(uint8_t da)   //д8λ����
//{
//	SPILCD_CS_RESET;  //LCD_CS=0
//	SPILCD_RS_SET;				    	   
//	SPI1_ReadWriteByte(da);	
//	SPILCD_CS_SET;  //LCD_CS=1   			 
//}					   
//д�Ĵ���
//LCD_Reg:�Ĵ�����ַ
//LCD_RegValue:Ҫд�������?

void LCD_WR_REG_DATA(uint8_t LCD_Reg, uint16_t LCD_RegValue)
{
	LCD_WR_REG(LCD_Reg);
	LCD_WR_DATA(LCD_RegValue);
}

//��ʼдGRAM
void LCD_WriteRAM_Prepare(void)
{
	LCD_WR_REG(lcddev.wramcmd);  
}	 
//��mdk -O1ʱ���Ż�ʱ��Ҫ����
//��ʱi
void opt_delay(uint8_t i)
{
	while(i--);
}  		 
//LCD������ʾ
void LCD_DisplayOn(void)
{					   

}	 
//LCD�ر���ʾ
void LCD_DisplayOff(void)
{	   

}   

//���ù��λ��?
//Xpos:������
//Ypos:������
void LCD_SetCursor(uint16_t Xpos, uint16_t Ypos)
{
    LCD_WR_REG(lcddev.setxcmd); 
	LCD_WR_DATA8(Xpos>>8); 
	LCD_WR_DATA8(Xpos&0XFF);	 
	LCD_WR_REG(lcddev.setycmd); 
	LCD_WR_DATA8(Ypos>>8); 
	LCD_WR_DATA8(Ypos&0XFF);
} 	  

//����
//x,y:����
//POINT_COLOR:�˵�����?
void LCD_DrawPoint(uint16_t x,uint16_t y)
{
	LCD_SetCursor(x,y);		//���ù��λ��? 
	LCD_WriteRAM_Prepare();	//��ʼд��GRAM
	LCD_WR_DATA(WHITE); 
} 

void LCD_DrawPointC(uint16_t x,uint16_t y,uint16_t color)
{
	LCD_SetCursor(x,y);		//���ù��λ��? 
	LCD_WriteRAM_Prepare();	//��ʼд��GRAM
	LCD_WR_DATA(color); 
} 

void DISP_WINDOWS(void)
{
         LCD_WR_REG(0x2A);
         LCD_WR_DATA8(0x00);
         LCD_WR_DATA8(0x00);
         LCD_WR_DATA8(0x00);
         LCD_WR_DATA8(0xEF);

         LCD_WR_REG(0x2B);
         LCD_WR_DATA8(0x00);
         LCD_WR_DATA8(0x00);
         LCD_WR_DATA8(0x01);
         LCD_WR_DATA8(0x3f);
         LCD_WR_REG(0x2C);
}


spi_t spi_master;

// SPI1 (S1)
#define SPI0_MOSI  PE_3
#define SPI0_MISO  PE_2
#define SPI0_SCLK  PE_1
#define SPI0_CS    PE_4
//  #define SPI0_CS    PF_8


//��ʼ��lcd
 void LCD_Init(void)
{ 	 	
	// SPI1_Init();
	// SPI1_SetSpeed(SPI_BaudRatePrescaler_2);
	// SPI1_ReadWriteByte(0xff);

	   spi_init(&spi_master, SPI0_MOSI, SPI0_MISO, SPI0_SCLK, SPI0_CS);
     
	   spi_format(&spi_master, 8, 1, 0);
	   spi_frequency(&spi_master, 10000000);
       spi_master_write(&spi_master, 0xff);  
		
//	LCD_REST=0;		 
// 	delay_ms(50); // delay 20 ms 
//  LCD_REST=1;		 
// 	delay_ms(50); // delay 20 ms 
	OLED_RST_Set() ;	//LCD_RST=1		
	Delay_ms(20);
	OLED_RST_Clr() ;	//LCD_RST=0	 //SPI�ӿڸ�λ
	Delay_ms(20);       // delay 20 ms 
    OLED_RST_Set() ;	//LCD_RST=1		
	Delay_ms(120);

	lcddev.width=240;
	lcddev.height=320;
//	lcddev.wramcmd=0X2C;  //�洢
//	lcddev.setxcmd=0X2A;  //�е�ַ
//	lcddev.setycmd=0X2B;  //ҳ��ַ

//	LCD_RESET=1;
//	delay (100); //Delay 100ms
//	LCD_RESET=0;
//	delay (200); //Delay 200ms
//	LCD_RESET=1;
//	delay (500); //Delay 500ms
	//---------------------------------------------------------------------------------------------------//
	LCD_WR_REG(0x11);
	Delay_ms(120); //Delay 120ms
	//------------------------------display and color format setting--------------------------------//
	LCD_WR_REG(0x36);
	LCD_WR_DATA8(0x00);
	LCD_WR_REG(0x3a);
	LCD_WR_DATA8(0x05);
	//--------------------------------ST7789V Frame rate setting----------------------------------//
	LCD_WR_REG(0xb2);
	LCD_WR_DATA8(0x0c);
	LCD_WR_DATA8(0x0c);
	LCD_WR_DATA8(0x00);
	LCD_WR_DATA8(0x33);
	LCD_WR_DATA8(0x33);
	LCD_WR_REG(0xb7);
	LCD_WR_DATA8(0x35);
	//---------------------------------ST7789V Power setting--------------------------------------//
	LCD_WR_REG(0xbb);
	LCD_WR_DATA8(0x1c);
	LCD_WR_REG(0xc0);
	LCD_WR_DATA8(0x2c);
	LCD_WR_REG(0xc2);
	LCD_WR_DATA8(0x01);
	LCD_WR_REG(0xc3);
	LCD_WR_DATA8(0x0b);
	LCD_WR_REG(0xc4);
	LCD_WR_DATA8(0x20);
	LCD_WR_REG(0xc6);
	LCD_WR_DATA8(0x0f);
	LCD_WR_REG(0xd0);
	LCD_WR_DATA8(0xa4);
	LCD_WR_DATA8(0xa1);
	//--------------------------------ST7789V gamma setting---------------------------------------//
	LCD_WR_REG(0xe0);
	LCD_WR_DATA8(0xd0);
	LCD_WR_DATA8(0x00);
	LCD_WR_DATA8(0x03);
	LCD_WR_DATA8(0x09);
	LCD_WR_DATA8(0x13);
	LCD_WR_DATA8(0x1c);
	LCD_WR_DATA8(0x3a);
	LCD_WR_DATA8(0x55);
	LCD_WR_DATA8(0x48);
	LCD_WR_DATA8(0x18);
	LCD_WR_DATA8(0x12);
	LCD_WR_DATA8(0x0e);
	LCD_WR_DATA8(0x19);
	LCD_WR_DATA8(0x1e);
	LCD_WR_REG(0xe1);
	LCD_WR_DATA8(0xd0);
	LCD_WR_DATA8(0x00);
	LCD_WR_DATA8(0x03);
	LCD_WR_DATA8(0x09);
	LCD_WR_DATA8(0x05);
	LCD_WR_DATA8(0x25);
	LCD_WR_DATA8(0x3a);
	LCD_WR_DATA8(0x55);
	LCD_WR_DATA8(0x50);
	LCD_WR_DATA8(0x3d);
	LCD_WR_DATA8(0x1c);
	LCD_WR_DATA8(0x1d);
	LCD_WR_DATA8(0x1d);
	LCD_WR_DATA8(0x1e);
//	LCD_WR_REG(0x21);
//	LCD_WR_REG(0x11);
	
	LCD_Clear(BLACK);
	LCD_WR_REG(0x29);
//	LCD_WR_REG(0x2c);
	Delay_ms(120);	
		
		
//        LCD_WR_DATA8(0x2C); 
//        LCD_WR_DATA8(0x00); 
//        LCD_WR_DATA8(0x34); 
//        LCD_WR_DATA8(0x02); 

//        LCD_WR_REG(0xCF);  
//        LCD_WR_DATA8(0x00); 
//        LCD_WR_DATA8(0XC1); 
//        LCD_WR_DATA8(0X30); 
// 
//        LCD_WR_REG(0xE8);  
//        LCD_WR_DATA8(0x85); 
//        LCD_WR_DATA8(0x00); 
//        LCD_WR_DATA8(0x78); 
// 
//        LCD_WR_REG(0xEA);  
//        LCD_WR_DATA8(0x00); 
//        LCD_WR_DATA8(0x00); 
// 
//        LCD_WR_REG(0xED);  
//        LCD_WR_DATA8(0x64); 
//        LCD_WR_DATA8(0x03); 
//        LCD_WR_DATA8(0X12); 
//        LCD_WR_DATA8(0X81); 

//        LCD_WR_REG(0xF7);  
//        LCD_WR_DATA8(0x20); 
//  
//        LCD_WR_REG(0xC0);    //Power control 
//        LCD_WR_DATA8(0x23);   //VRH[5:0] 
// 
//        LCD_WR_REG(0xC1);    //Power control 
//        LCD_WR_DATA8(0x10);   //SAP[2:0];BT[3:0] 
// 
//        LCD_WR_REG(0xC5);    //VCM control 
//        LCD_WR_DATA8(0x3e); //�Աȶȵ���
//        LCD_WR_DATA8(0x28); 
// 
//        LCD_WR_REG(0xC7);    //VCM control2 
//        LCD_WR_DATA8(0x86);  //--
// 
//        LCD_WR_REG(0x36);    // Memory Access Control 
//        LCD_WR_DATA8(0x48); //C8	   //48 68����//28 E8 ����

//        LCD_WR_REG(0x3A);    
//        LCD_WR_DATA8(0x55); 

//        LCD_WR_REG(0xB1);    
//        LCD_WR_DATA8(0x00);  
//        LCD_WR_DATA8(0x18); 
// 
//        LCD_WR_REG(0xB6);    // Display Function Control 
//        LCD_WR_DATA8(0x08); 
//        LCD_WR_DATA8(0x82);
//        LCD_WR_DATA8(0x27);  
// 
//        LCD_WR_REG(0xF2);    // 3Gamma Function Disable 
//        LCD_WR_DATA8(0x00); 
// 
//        LCD_WR_REG(0x26);    //Gamma curve selected 
//        LCD_WR_DATA8(0x01); 
// 
//        LCD_WR_REG(0xE0);    //Set Gamma 
//        LCD_WR_DATA8(0x0F); 
//        LCD_WR_DATA8(0x31); 
//        LCD_WR_DATA8(0x2B); 
//        LCD_WR_DATA8(0x0C); 
//        LCD_WR_DATA8(0x0E); 
//        LCD_WR_DATA8(0x08); 
//        LCD_WR_DATA8(0x4E); 
//        LCD_WR_DATA8(0xF1); 
//        LCD_WR_DATA8(0x37); 
//        LCD_WR_DATA8(0x07); 
//        LCD_WR_DATA8(0x10); 
//        LCD_WR_DATA8(0x03); 
//        LCD_WR_DATA8(0x0E); 
//        LCD_WR_DATA8(0x09); 
//        LCD_WR_DATA8(0x00); 

//        LCD_WR_REG(0XE1);    //Set Gamma 
//        LCD_WR_DATA8(0x00); 
//        LCD_WR_DATA8(0x0E); 
//        LCD_WR_DATA8(0x14); 
//        LCD_WR_DATA8(0x03); 
//        LCD_WR_DATA8(0x11); 
//        LCD_WR_DATA8(0x07); 
//        LCD_WR_DATA8(0x31); 
//        LCD_WR_DATA8(0xC1); 
//        LCD_WR_DATA8(0x48); 
//        LCD_WR_DATA8(0x08); 
//        LCD_WR_DATA8(0x0F); 
//        LCD_WR_DATA8(0x0C); 
//        LCD_WR_DATA8(0x31); 
//        LCD_WR_DATA8(0x36); 
//        LCD_WR_DATA8(0x0F); 
// 
//        LCD_WR_REG(0x11);    //Exit Sleep 
//        delay_ms(50);
////		DISP_WINDOWS();
//				
////        LCD_WR_REG(0x29);    //Display on 
////        LCD_WR_REG(0x2c); 
//		LCD_Clear(BLACK);
//		 delay_ms(50);	
}  
//��������
//color:Ҫ����������?
//void LCD_Clear(uint16_t color)
//{
//	uint32_t index=0;      
//	uint32_t totalpoint=lcddev.width;
//	totalpoint*=lcddev.height; 	//�õ��ܵ���
//	DISP_WINDOWS();
//	LCD_SetCursor(0x00,0x0000);	//���ù��λ��? 
//	LCD_WriteRAM_Prepare();     //��ʼд��GRAM	 	  
//	for(index=0;index<totalpoint;index++)
//	{
//		LCD_WR_DATA(color);
//	}

//}  
//��ָ����������䵥�����?
//(sx,sy),(ex,ey):�����ζԽ�����,�����С�?:(ex-sx+1)*(ey-sy+1)   
//color:Ҫ������ɫ
void LCD_Fill(uint16_t sx,uint16_t sy,uint16_t ex,uint16_t ey,uint16_t color)
{          
	uint16_t i,j;
	uint16_t xlen=0;
	xlen=ex-sx+1;	   
	for(i=sy;i<=ey;i++)
	{									   
	 	LCD_SetCursor(sx,i);      				//���ù��λ��? 
		LCD_WriteRAM_Prepare();     			//��ʼд��GRAM	  
		for(j=0;j<xlen;j++)LCD_WR_DATA(color);	//���ù��λ��? 	    
	}
}  
//��ָ�����������ָ�����?��			 
//(sx,sy),(ex,ey):�����ζԽ�����,�����С�?:(ex-sx+1)*(ey-sy+1)   
//color:Ҫ������ɫ
void LCD_Color_Fill(uint16_t sx,uint16_t sy,uint16_t ex,uint16_t ey,uint16_t *color)
{  
	uint16_t height,width;
	uint16_t i,j;
	width=ex-sx+1; 		//�õ����Ŀ���
	height=ey-sy+1;		//�߶�
 	for(i=0;i<height;i++)
	{
 		LCD_SetCursor(sx,sy+i);   	//���ù��λ��? 
		LCD_WriteRAM_Prepare();     //��ʼд��GRAM
		for(j=0;j<width;j++)LCD->LCD_RAM=color[i*height+j];//д������ 
	}	  
}  
//����
//x1,y1:�������?
//x2,y2:�յ�����  
void LCD_DrawLine(uint16_t x1, uint16_t y1, uint16_t x2, uint16_t y2)
{
	uint16_t t; 
	int xerr=0,yerr=0,delta_x,delta_y,distance; 
	int incx,incy,uRow,uCol; 
	delta_x=x2-x1; //������������ 
	delta_y=y2-y1; 
	uRow=x1; 
	uCol=y1; 
	if(delta_x>0)incx=1; //���õ������� 
	else if(delta_x==0)incx=0;//��ֱ�� 
	else { incx=-1;delta_x=-delta_x; } 
	if(delta_y>0)incy=1; 
	else if(delta_y==0)incy=0;//ˮƽ�� 
	else{incy=-1;delta_y=-delta_y;} 
	if( delta_x>delta_y)distance=delta_x; //ѡȡ�������������� 
	else distance=delta_y; 
	for(t=0;t<=distance+1;t++ )//�������? 
	{  
		LCD_DrawPoint(uRow,uCol);//���� 
		xerr+=delta_x ; 
		yerr+=delta_y ; 
		if(xerr>distance) 
		{ 
			xerr-=distance; 
			uRow+=incx; 
		} 
		if(yerr>distance) 
		{ 
			yerr-=distance; 
			uCol+=incy; 
		} 
	}  
}    

void LCD_DrawLineC(uint16_t x1, uint16_t y1, uint16_t x2, uint16_t y2,uint16_t color)
{
	uint16_t t; 
	int xerr=0,yerr=0,delta_x,delta_y,distance; 
	int incx,incy,uRow,uCol; 
	delta_x=x2-x1; //������������ 
	delta_y=y2-y1; 
	uRow=x1; 
	uCol=y1; 
	if(delta_x>0)incx=1; //���õ������� 
	else if(delta_x==0)incx=0;//��ֱ�� 
	else {incx=-1;delta_x=-delta_x;} 
	if(delta_y>0)incy=1; 
	else if(delta_y==0)incy=0;//ˮƽ�� 
	else{incy=-1;delta_y=-delta_y;} 
	if( delta_x>delta_y)distance=delta_x; //ѡȡ�������������� 
	else distance=delta_y; 
	for(t=0;t<=distance+1;t++ )//�������? 
	{  
		LCD_DrawPointC(uRow,uCol,color);//���� 
		xerr+=delta_x ; 
		yerr+=delta_y ; 
		if(xerr>distance) 
		{ 
			xerr-=distance; 
			uRow+=incx; 
		} 
		if(yerr>distance) 
		{ 
			yerr-=distance; 
			uCol+=incy; 
		} 
	}  
}
//������	  
//(x1,y1),(x2,y2):���εĶԽ�����
void LCD_DrawRectangle(uint16_t x1, uint16_t y1, uint16_t x2, uint16_t y2,uint16_t color)
{
	LCD_DrawLineC(x1,y1,x2,y1,color);
	LCD_DrawLineC(x1,y1,x1,y2,color);
	LCD_DrawLineC(x1,y2,x2,y2,color);
	LCD_DrawLineC(x2,y1,x2,y2,color);
}
//��ָ��λ�û�һ��ָ����С��Բ
//(x,y):���ĵ�
//r    :�뾶
void Draw_Circle(uint16_t x0,uint16_t y0,uint8_t r)
{
	int a,b;
	int di;
	a=0;b=r;	  
	di=3-(r<<1);             //�ж��¸���λ�õı�־
	while(a<=b)
	{
		LCD_DrawPoint(x0+a,y0-b);             //5
 		LCD_DrawPoint(x0+b,y0-a);             //0           
		LCD_DrawPoint(x0+b,y0+a);             //4               
		LCD_DrawPoint(x0+a,y0+b);             //6 
		LCD_DrawPoint(x0-a,y0+b);             //1       
 		LCD_DrawPoint(x0-b,y0+a);             
		LCD_DrawPoint(x0-a,y0-b);             //2             
  		LCD_DrawPoint(x0-b,y0-a);             //7     	         
		a++;
		//ʹ��Bresenham�㷨��Բ     
		if(di<0)di +=4*a+6;	  
		else
		{
			di+=10+4*(a-b);   
			b--;
		} 						    
	}
} 	
//��ָ��λ����ʾһ������(16*16��С)
void showhanzi16(unsigned int x,unsigned int y,unsigned char index,uint16_t color)	
{  
	unsigned char i,j,k;
	const unsigned char *temp=hanzi16;    
	temp+=index*32;	
	for(j=0;j<16;j++)
	{
		LCD_SetCursor(x,y+j);
		LCD_WriteRAM_Prepare();	//��ʼд��GRAM
		for(k=0;k<2;k++)
		{
			for(i=0;i<8;i++)
			{ 		     
			 	if((*temp&(1<<i))!=0)
				{
					LCD_WR_DATA(color);
				} 
				else
				{
					LCD_WR_DATA(BLACK);
				}   
			}
			temp++;
		}
	 }
}	
void showhanzi24(unsigned int x,unsigned int y,unsigned char index,uint16_t color)	   //24*24
{  
	unsigned char i,j,k;
	const unsigned char *temp=hanzi24;    
	temp+=index*72;	
	for(j=0;j<24;j++)
	{
		LCD_SetCursor(x,y+j);
		LCD_WriteRAM_Prepare();	//��ʼд��GRAM
		for(k=0;k<3;k++)
		{
			for(i=0;i<8;i++)
			{ 		     
			 	if((*temp&(1<<i))!=0)
				{
					LCD_WR_DATA(color);
				} 
				else
				{
					LCD_WR_DATA(BLACK);
				}   
			}
			temp++;
		}
	 }
}	
//��ָ��λ����ʾһ������(32*32��С)
void showhanzi32(unsigned int x,unsigned int y,unsigned char index,uint16_t color)	
{  
	unsigned char i,j,k;
	const unsigned char *temp=hanzi32;    
	temp+=index*128;	
	for(j=0;j<32;j++)
	{
		LCD_SetCursor(x,y+j);
		LCD_WriteRAM_Prepare();	//��ʼд��GRAM
		for(k=0;k<4;k++)
		{
			for(i=0;i<8;i++)
			{ 		     
			 	if((*temp&(1<<i))!=0)
				{
					LCD_WR_DATA(WHITE);
				} 
				else
				{
					LCD_WR_DATA(BLACK);
				}   
			}
			temp++;
		}
	 }
}													  
//��ָ��λ����ʾһ���ַ�
//x,y:��ʼ����
//num:Ҫ��ʾ���ַ�:" "--->"~"
//size:������? 12/16
//mode:���ӷ�ʽ(1)���Ƿǵ��ӷ�ʽ(0)
//void LCD_ShowChar(uint16_t x,uint16_t y,uint8_t num,uint8_t size,uint8_t mode)
//{  							  
//    uint8_t temp,t1,t;
//	uint16_t y0=y;
//	uint16_t colortemp=POINT_COLOR;      			     
//	//���ô���		   
//	num=num-' ';//�õ�ƫ�ƺ���?
//	if(!mode) //�ǵ��ӷ�ʽ
//	{
//	    for(t=0;t<size;t++)
//	    {   
//			if(size==12)temp=asc2_1206[num][t];  //����1206����
//			else if(size==16)temp=asc2_1608[num][t];		 //����1608���� 	  
//			else if(size==24)temp=asc2_2412[num][t];
//			else temp=asc2_2432[num][t];
//	        for(t1=0;t1<8;t1++)
//			{			    
//		        if(temp&0x80)POINT_COLOR=colortemp;
//				else POINT_COLOR=BACK_COLOR;
//				LCD_DrawPoint(x,y);	
//				temp<<=1;
//				y++;
//				if(y>=lcddev.height){POINT_COLOR=colortemp;return;}//��������
//				if((y-y0)==size)
//				{
//					y=y0;
//					x++;
//					if(x>=lcddev.width){POINT_COLOR=colortemp;return;}//��������
//					break;
//				}
//			}  	 
//	    }    
//	}else//���ӷ�ʽ
//	{
//	    for(t=0;t<size;t++)
//	    {   
//			if(size==12)temp=asc2_1206[num][t];  //����1206����
//			else if(size==16)temp=asc2_1608[num][t];		 //����1608���� 	  
//			else if(size==24)temp=asc2_2412[num][t]; 
//			else temp=asc2_2432[num][t];			
//	        for(t1=0;t1<8;t1++)
//			{			    
//		        if(temp&0x80)LCD_DrawPoint(x,y); 
//				temp<<=1;
//				y++;
//				if(y>=lcddev.height){POINT_COLOR=colortemp;return;}//��������
//				if((y-y0)==size)
//				{
//					y=y0;
//					x++;
//					if(x>=lcddev.width){POINT_COLOR=colortemp;return;}//��������
//					break;
//				}
//			}  	 
//	    }     
//	}
//	POINT_COLOR=colortemp;	    	   	 	  
//}   
void LCD_ShowChar(uint16_t x,uint16_t y,uint8_t num,uint8_t size,uint8_t mode)
{  							  
    uint8_t temp,t1,t;
	uint16_t y0=y;
	uint8_t csize=(size/8+((size%8)?1:0))*(size/2);		//�õ�����һ���ַ���Ӧ������ռ���ֽ���	
 	num=num-' ';//�õ�ƫ�ƺ��ֵ��ASCII�ֿ��Ǵӿո�ʼȡģ������ -' '���Ƕ�Ӧ�ַ����ֿ⣩
	for(t=0;t<csize;t++)
	{   
		if(size==12)temp=asc2_1206[num][t]; 	 	//����1206����
		else if(size==16)temp=asc2_1608[num][t];	//����1608����
		else if(size==24)temp=asc2_2412[num][t];	//����2412����
		else temp=asc2_2432[num][t];								//û�е��ֿ�
		for(t1=0;t1<8;t1++)
		{			    
			if(temp&0x80)LCD_DrawPoint(x,y);
			else if(mode==0)LCD_DrawPoint(x,y);
			temp<<=1;
			y++;
			if(y>=lcddev.height)return;		//��������
			if((y-y0)==size)
			{
				y=y0;
				x++;
				if(x>=lcddev.width)return;	//��������
				break;
			}
		}  	 
	}  	    	   	 	  
}


//m^n����
//����ֵ:m^n�η�.
uint32_t LCD_Pow(uint8_t m,uint8_t n)
{
	uint32_t result=1;	 
	while(n--)result*=m;    
	return result;
}			 
//��ʾ����,��λΪ0,����ʾ
//x,y :�������?	 
//len :���ֵ�λ��
//size:������?
//color:��ɫ 
//num:��ֵ(0~4294967295);	 
void LCD_ShowNum(uint16_t x,uint16_t y,uint32_t num,uint8_t len,uint8_t size)
{         	
	uint8_t t,temp;
	uint8_t enshow=0;						   
	for(t=0;t<len;t++)
	{
		temp=(num/LCD_Pow(10,len-t-1))%10;
		if(enshow==0&&t<(len-1))
		{
			if(temp==0)
			{
				LCD_ShowChar(x+(size/2)*t,y,' ',size,0);
				continue;
			}else enshow=1; 
		 	 
		}
	 	LCD_ShowChar(x+(size/2)*t,y,temp+'0',size,0); 
	}
} 
//��ʾ����,��λΪ0,������ʾ
//x,y:�������?
//num:��ֵ(0~999999999);	 
//len:����(��Ҫ��ʾ��λ��)
//size:������?
//mode:
//[7]:0,�����?;1,���?0.
//[6:1]:����
//[0]:0,�ǵ�����ʾ;1,������ʾ.
void LCD_ShowxNum(uint16_t x,uint16_t y,uint32_t num,uint8_t len,uint8_t size,uint8_t mode)
{  
	uint8_t t,temp;
	uint8_t enshow=0;						   
	for(t=0;t<len;t++)
	{
		temp=(num/LCD_Pow(10,len-t-1))%10;
		if(enshow==0&&t<(len-1))
		{
			if(temp==0)
			{
				LCD_ShowChar(x+(size/2)*t,y,'0',size,mode&0X01);  
//				else LCD_ShowChar(x+(size/2)*t,y,' ',size,mode&0X01);  
 				continue;
			}else enshow=1; 
		 	 
		}
	 	LCD_ShowChar(x+(size/2)*t,y,temp+'0',size,mode&0X01); 
	}
} 
void LCD_ShowxNum1(uint16_t x,uint16_t y,uint32_t num,uint8_t len,uint8_t size,uint8_t mode)
{  
	uint8_t t,temp;
	uint8_t enshow=0;						   
	for(t=0;t<len;t++)
	{
		temp=(num/LCD_Pow(10,len-t-1))%10;
		if(enshow==0&&t<(len-1))
		{
			if(temp==0)
			{
				if(mode&0X80)LCD_ShowChar(x+(size/2)*t,y,'0',size,mode&0X01);  
				else LCD_ShowChar(x,y,' ',size,mode&0X01);  
 				continue;
			}else enshow=1; 
		 	 
		}
	 	LCD_ShowChar(x+(size/2)*t,y,temp+'0',size,mode&0X01); 
	}
} 
//void LCD_ShowxNum1(uint16_t x,uint16_t y,uint32_t num,uint8_t len,uint8_t size)
//{         	
//	uint8_t t,temp;
//	uint8_t enshow=0;						   
//	for(t=0;t<len;t++)
//	{
//		temp=(num/LCD_Pow(10,len-t-1))%10;
//		if(enshow==0&&t<(len-1))
//		{
//			if(temp==0)
//			{
//				LCD_ShowChar(x+(size/2)*t,y,' ',size,0);
//				continue;
//			}else enshow=1; 
//		 	 
//		}
//	 	LCD_ShowChar(x+(size/2)*t,y,temp+'0',size,0); 
//	}
//} 
//��ʾ�ַ���
//x,y:�������?
//width,height:������?  
//size:������?
//*p:�ַ�����ʼ��ַ		  
void LCD_ShowString(uint16_t x,uint16_t y,uint16_t width,uint16_t height,uint8_t size,uint8_t *p)
{         
	uint8_t x0=x;
	width+=x;
	height+=y;
    while((*p<='~')&&(*p>=' '))//�ж��ǲ��ǷǷ��ַ�!
    {       
        if(x>=width){x=x0;y+=size;}
        if(y>=height)break;//�˳�
        LCD_ShowChar(x,y,*p,size,1);
        x+=size/2;
        p++;
    }  
}

void showimage(uint16_t x,uint16_t y) //��ʾ40*40ͼƬ
{  
	uint16_t i,j,k;
	uint16_t da;
	k=0;
	for(i=0;i<40;i++)
	{	
		LCD_SetCursor(x,y+i);
		LCD_WriteRAM_Prepare();     			//��ʼд��GRAM	
		for(j=0;j<40;j++)
		{
			da=qqimage[k*2+1];
			da<<=8;
			da|=qqimage[k*2]; 
			LCD_WR_DATA(da);					
			k++;  			
		}
	}
}












//��������ʾ����֮ǰ���ֹ�����ȫ���������������Ա����ʼ����������? �Լ����ִ���SPI���Ƶ� �ֱ���Ϊ320*240 ������ʾ
/******************************************************************************
      ����˵����LCD��ʼ������
      ������ݣ���?
      ����ֵ��  ��
******************************************************************************/
void ST7789Lcd_Init(void)
{
//      ST7789_GPIO_Config();
//      SPI3_Init();
//      SPI3_SetSpeed(SPI_BaudRatePrescaler_2);
//      SPI3_ReadWriteByte(0xff);
		lcddev.width=240;
		lcddev.height=320;
		lcddev.wramcmd=0X2C;  //�洢
		lcddev.setxcmd=0X2A;  //�е�ַ
		lcddev.setycmd=0X2B;  //ҳ��ַ
		// SPI1_Init();
		// SPI1_SetSpeed(SPI_BaudRatePrescaler_2);
		// SPI1_ReadWriteByte(0xff);

	    spi_init(&spi_master, SPI0_MOSI, SPI0_MISO, SPI0_SCLK, SPI0_CS);
     
	    spi_format(&spi_master, 8, 0, 0);
	    spi_frequency(&spi_master, 10000000);//10M   MAX 13M
	    hal_ssi_toggle_between_frame(&spi_master.hal_ssi_adaptor, ENABLE);
        // spi_master_write(&spi_master, 0xff);  

		OLED_RST_Set();   //1
		Delay_ms(10);    
		OLED_RST_Clr();   //0
		Delay_ms(10);
		OLED_RST_Set();   //1
		Delay_ms(120);
		//************************************************
		//                LCD_WR_REG(0x3A);        //65k mode
		//                LCD_WR_DATA8(0x05);
		LCD_WR_REG(0x11);
		Delay_ms (120); //Delay 120ms
		//------------------------------display and color format setting--------------------------------//
		LCD_WR_REG(0x36);
		LCD_WR_DATA8(0x00);
		LCD_WR_REG(0x3a);
		LCD_WR_DATA8(0x05);

        //add
		LCD_WR_REG(0xb0);
		LCD_WR_DATA8(0x00);
		LCD_WR_DATA8(0xe0);

		//--------------------------------ST7789V Frame rate setting----------------------------------//
		LCD_WR_REG(0xb2);
		LCD_WR_DATA8(0x0c);
		LCD_WR_DATA8(0x0c);
		LCD_WR_DATA8(0x00);
		LCD_WR_DATA8(0x33);
		LCD_WR_DATA8(0x33);

		LCD_WR_REG(0xb7);
		LCD_WR_DATA8(0x35);
		//---------------------------------ST7789V Power setting--------------------------------------//
		LCD_WR_REG(0xbb);
		// LCD_WR_DATA8(0x1c);
		LCD_WR_DATA8(0x2b);

		LCD_WR_REG(0xc0);
		LCD_WR_DATA8(0x2c);

		LCD_WR_REG(0xc2);
		LCD_WR_DATA8(0x01);

		LCD_WR_REG(0xc3);
		// LCD_WR_DATA8(0x0b);
		LCD_WR_DATA8(0x11);

		LCD_WR_REG(0xc4);
		LCD_WR_DATA8(0x20);

		LCD_WR_REG(0xc6);
		LCD_WR_DATA8(0x0f);

		LCD_WR_REG(0xd0);
		LCD_WR_DATA8(0xa4);
		LCD_WR_DATA8(0xa1);
		//--------------------------------ST7789V gamma setting---------------------------------------//
		LCD_WR_REG(0xe0);
		// LCD_WR_DATA8(0xd0);
		// LCD_WR_DATA8(0x00);
		// LCD_WR_DATA8(0x03);
		// LCD_WR_DATA8(0x09);
		// LCD_WR_DATA8(0x13);
		// LCD_WR_DATA8(0x1c);
		// LCD_WR_DATA8(0x3a);
		// LCD_WR_DATA8(0x55);
		// LCD_WR_DATA8(0x48);
		// LCD_WR_DATA8(0x18);
		// LCD_WR_DATA8(0x12);
		// LCD_WR_DATA8(0x0e);
		// LCD_WR_DATA8(0x19);
		// LCD_WR_DATA8(0x1e);
		
		LCD_WR_DATA8(0xd0);
		LCD_WR_DATA8(0x00);
		LCD_WR_DATA8(0x05);
		LCD_WR_DATA8(0x0e);
		LCD_WR_DATA8(0x15);
		LCD_WR_DATA8(0x0d);
		LCD_WR_DATA8(0x37);
		LCD_WR_DATA8(0x43);
		LCD_WR_DATA8(0x47);
		LCD_WR_DATA8(0x09);
		LCD_WR_DATA8(0x15);
		LCD_WR_DATA8(0x12);
		LCD_WR_DATA8(0x16);
		LCD_WR_DATA8(0x19);

		LCD_WR_REG(0xe1);
		// LCD_WR_DATA8(0xd0);
		// LCD_WR_DATA8(0x00);
		// LCD_WR_DATA8(0x03);
		// LCD_WR_DATA8(0x09);
		// LCD_WR_DATA8(0x05);
		// LCD_WR_DATA8(0x25);
		// LCD_WR_DATA8(0x3a);
		// LCD_WR_DATA8(0x55);
		// LCD_WR_DATA8(0x50);
		// LCD_WR_DATA8(0x3d);
		// LCD_WR_DATA8(0x1c);
		// LCD_WR_DATA8(0x1d);
		// LCD_WR_DATA8(0x1d);
		// LCD_WR_DATA8(0x1e);

		LCD_WR_DATA8(0xd0);
		LCD_WR_DATA8(0x00);
		LCD_WR_DATA8(0x05);
		LCD_WR_DATA8(0x0d);
		LCD_WR_DATA8(0x0c);
		LCD_WR_DATA8(0x06);
		LCD_WR_DATA8(0x2d);
		LCD_WR_DATA8(0x44);
		LCD_WR_DATA8(0x40);
		LCD_WR_DATA8(0x0e);
		LCD_WR_DATA8(0x1c);
		LCD_WR_DATA8(0x18);
		LCD_WR_DATA8(0x16);
		LCD_WR_DATA8(0x19);

        LCD_WR_REG(0xe7);
	  	LCD_WR_DATA8(0x00);

		LCD_WR_REG(0x29);
		LCD_WR_REG(0x2c);

		//LCD_WR_REG(0x29);
		LCD_Clear(RED);         
		Lcd_GramScan(1);   
		LCD_WR_REG(0x29);       
}

/******************************************************************************
      ����˵����LCDд������
      ������ݣ�dat д�������?
      ����ֵ��  ��
******************************************************************************/

void LCD_WR_DATA8(uint8_t dat)
{
         SPILCD_CS_RESET;
        SPILCD_RS_SET;//д����
        // SPI1_ReadWriteByte(dat);
		spi_master_write(&spi_master,dat);
          SPILCD_CS_SET;        
}
void LCD_WR_DATA(uint16_t dat)
{
        SPILCD_CS_RESET;
        SPILCD_RS_SET;//д����
        // SPI1_ReadWriteByte(dat>>8);
        // SPI1_ReadWriteByte(dat);
		spi_master_write(&spi_master,dat>>8);
		spi_master_write(&spi_master,dat);
        SPILCD_CS_SET;        
}

void LCD_Address_Set(uint16_t x1,uint16_t y1,uint16_t x2,uint16_t y2)
{
     LCD_WR_REG(0x2a);//
     LCD_WR_DATA(x1);
     LCD_WR_DATA(x2);
     LCD_WR_REG(0x2b);//
     LCD_WR_DATA(y1);
     LCD_WR_DATA(y2);
     LCD_WR_REG(0x2c);//
}

void LCD_Clear(uint16_t color)
{
   uint16_t i,j;         
   LCD_Address_Set(0,0,240,320);
   for(i=0;i<240;i++)
     {
      for (j=0;j<320;j++)
        {
         LCD_WR_DATA(color);
        }
     }
}



//LCD_WR_REG
void LCD_WR_REG(uint8_t dat)
{
         SPILCD_CS_RESET;
         SPILCD_RS_RESET;//д����
        // SPI1_ReadWriteByte(dat);
	 	 spi_master_write(&spi_master,dat);
         SPILCD_CS_SET;     
}



void Lcd_GramScan(uint8_t option)
{	
	switch(option)
	{
		case 1:
		{/* ���Ͻ�->���½ǣ�������*/
			LCD_WR_REG(0x36); 
			LCD_WR_DATA8(0x08);  
			
			LCD_WR_REG(0X2A); 
			LCD_WR_DATA8(0x00);	/* x start */	
			LCD_WR_DATA8(0x00);
			LCD_WR_DATA8(0x00);  /* x end */	
			LCD_WR_DATA8(0xEF);

			LCD_WR_DATA8(0X2B); 
			LCD_WR_DATA8(0x00);	/* y start */  
			LCD_WR_DATA8(0x00);
			LCD_WR_DATA8(0x01);	/* y end */   
			LCD_WR_DATA8(0x3F);					
		}break;
		case 2:
		{/* ���½�->���Ͻǣ�������*/
			LCD_WR_REG(0x36); 
			LCD_WR_DATA8(0x88);	
			
			LCD_WR_REG(0X2A); 
			LCD_WR_DATA8(0x00);	/* x start */	
			LCD_WR_DATA8(0x00);
			LCD_WR_DATA8(0x00);  /* x end */	
			LCD_WR_DATA8(0xEF);

			LCD_WR_REG(0X2B); 
			LCD_WR_DATA8(0x00);	/* y start */  
			LCD_WR_DATA8(0x00);
			LCD_WR_DATA8(0x01);	/* y end */   
			LCD_WR_DATA8(0x3F);		
		}break;
		case 3:
		{/* ���Ͻ�->���½ǣ�������*/
			LCD_WR_REG(0x36); 
			LCD_WR_DATA8(0x48);	
			
			LCD_WR_REG(0X2A); 
			LCD_WR_DATA8(0x00);	/* x start */	
			LCD_WR_DATA8(0x00);
			LCD_WR_DATA8(0x00);  /* x end */	
			LCD_WR_DATA8(0xEF);

			LCD_WR_REG(0X2B); 
			LCD_WR_DATA8(0x00);	/* y start */  
			LCD_WR_DATA8(0x00);
			LCD_WR_DATA8(0x01);	/* y end */   
			LCD_WR_DATA8(0x3F);		
		}break;
		case 4:
		{/* ���½�->���Ͻǣ�������*/
			LCD_WR_REG(0x36); 
			LCD_WR_DATA8(0xC8);   
			
			LCD_WR_REG(0X2A); 
			LCD_WR_DATA8(0x00);	/* x start */	
			LCD_WR_DATA8(0x00);
			LCD_WR_DATA8(0x00);  /* x end */	
			LCD_WR_DATA8(0xEF);

			LCD_WR_REG(0X2B); 
			LCD_WR_DATA8(0x00);	/* y start */  
			LCD_WR_DATA8(0x00);
			LCD_WR_DATA8(0x01);	/* y end */   
			LCD_WR_DATA8(0x3F);					
		}break;
		case 5:
		{/* ���Ͻ�->���½ǣ�������*/	
			LCD_WR_REG(0x36); 
			LCD_WR_DATA8(0x28);
			
			LCD_WR_REG(0X2A); 
			LCD_WR_DATA8(0x00);
			LCD_WR_DATA8(0x00);
			LCD_WR_DATA8(0x01);
			LCD_WR_DATA8(0x3F);	

			LCD_WR_REG(0X2B); 
			LCD_WR_DATA8(0x00);
			LCD_WR_DATA8(0x00);
			LCD_WR_DATA8(0x00);
			LCD_WR_DATA8(0xEF);			
		}break;
		case 6:
		{/* ���½�->���Ͻǣ�������*/
			LCD_WR_REG(0x36); 
			LCD_WR_DATA8(0xA8);	
			
			LCD_WR_REG(0X2A); 
			LCD_WR_DATA8(0x00);
			LCD_WR_DATA8(0x00);
			LCD_WR_DATA8(0x01);
			LCD_WR_DATA8(0x3F);	

			LCD_WR_REG(0X2B); 
			LCD_WR_DATA8(0x00);
			LCD_WR_DATA8(0x00);
			LCD_WR_DATA8(0x00);
			LCD_WR_DATA8(0xEF);			
		}break;
		case 7:
		{/* ���Ͻ�->���½ǣ�������*/
			LCD_WR_REG(0x36); 
			LCD_WR_DATA8(0x68);   
			
			LCD_WR_REG(0X2A); 
			LCD_WR_DATA8(0x00);
			LCD_WR_DATA8(0x00);
			LCD_WR_DATA8(0x01);
			LCD_WR_DATA8(0x3F);	

			LCD_WR_REG(0X2B); 
			LCD_WR_DATA8(0x00);
			LCD_WR_DATA8(0x00);
			LCD_WR_DATA8(0x00);
			LCD_WR_DATA8(0xEF);						
		}break;
		case 8:
		{/* ���½�->���Ͻǣ�������*/	
			LCD_WR_REG(0x36); 
			LCD_WR_DATA8(0xE8);	
			
			LCD_WR_REG(0X2A); 
			LCD_WR_DATA8(0x00);
			LCD_WR_DATA8(0x00);
			LCD_WR_DATA8(0x01);
			LCD_WR_DATA8(0x3F);	

			LCD_WR_REG(0X2B); 
			LCD_WR_DATA8(0x00);
			LCD_WR_DATA8(0x00);
			LCD_WR_DATA8(0x00);
			LCD_WR_DATA8(0xEF);				
		}break;
	}	
}









